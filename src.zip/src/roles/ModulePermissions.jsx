import React from "react";
import "./Roles.css";

const ModulePermissions = ({
  menuSections,
  selectedModules = [],
  onModuleToggle,
  isDisabled = false
}) => {
  return (
    <div className="modules-container">
      <h3>Módulos accesibles</h3>
      <div className="modules-grid">
        {menuSections.map((section, sectionIndex) => (
          <div key={sectionIndex} className="module-section">
            <h4>{section.title}</h4>
            <div className="module-items">
              {section.items.map((item, itemIndex) => {
                const fullPath = `${section.title.toLowerCase()}-${item.path}`;
                return (
                  <label
                    key={itemIndex}
                    className="module-checkbox"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <input
                      type="checkbox"
                      name={`module-${sectionIndex}-${itemIndex}`}
                      checked={selectedModules.includes(fullPath)}
                      onChange={() => onModuleToggle(fullPath)}
                      disabled={isDisabled}
                    />
                    {item.name}
                  </label>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ModulePermissions;
