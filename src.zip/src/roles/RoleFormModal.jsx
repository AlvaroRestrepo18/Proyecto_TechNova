import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes } from "@fortawesome/free-solid-svg-icons";
import ModulePermissions from "./ModulePermissions";
import "./Roles.css";

const RoleFormModal = ({
  isOpen,
  onClose,
  formData,
  onChange,
  onSubmit,
  onDelete,
  menuSections,
  mode = "create"
}) => {
  const [errors, setErrors] = useState({});
  const isViewMode = mode === "view";

  const handleModuleToggle = (modulePath) => {
    if (isViewMode) return; // Bloquea cambios si es solo vista

    const newModules = formData.modules.includes(modulePath)
      ? formData.modules.filter((m) => m !== modulePath)
      : [...formData.modules, modulePath];

    onChange({
      target: {
        name: "modules",
        value: newModules
      }
    });
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.nombre || formData.nombre.trim().length < 3) {
      newErrors.nombre = "Debe tener al menos 3 caracteres";
    }

    if (!formData.descripcion || formData.descripcion.trim().length < 5) {
      newErrors.descripcion = "Debe tener al menos 5 caracteres";
    }

    if (!formData.modules || formData.modules.length === 0) {
      newErrors.modules = "Debe seleccionar al menos un módulo";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) {
      onSubmit();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>
            {mode === "create"
              ? "Crear Rol"
              : mode === "edit"
              ? "Editar Rol"
              : "Detalles del Rol"}
          </h2>
          <button className="close-button" onClick={onClose}>
            <FontAwesomeIcon icon={faTimes} />
          </button>
        </div>

        <div className="form-body">
          <div className="form-group">
            <label>
              Nombre del Rol: <span className="required-asterisk">*</span>
            </label>
            <input
              type="text"
              name="nombre"
              value={formData.nombre}
              onChange={onChange}
              placeholder="Nombre del rol"
              disabled={isViewMode}
            />
            {errors.nombre && <small className="error">{errors.nombre}</small>}
          </div>

          <div className="form-group">
            <label>
              Descripción: <span className="required-asterisk">*</span>
            </label>
            <textarea
              name="descripcion"
              value={formData.descripcion}
              onChange={onChange}
              placeholder="Descripción del rol"
              disabled={isViewMode}
            />
            {errors.descripcion && (
              <small className="error">{errors.descripcion}</small>
            )}
          </div>

          <label>
            Permisos / Módulos: <span className="required-asterisk">*</span>
          </label>
          <ModulePermissions
            menuSections={menuSections}
            selectedModules={formData.modules || []}
            onModuleToggle={handleModuleToggle}
            isDisabled={isViewMode} 
          />
          {errors.modules && (
            <small className="error">{errors.modules}</small>
          )}

          <div className="form-actions">
            <button type="button" className="cancel-button" onClick={onClose}>
              {isViewMode ? "Cerrar" : "Cancelar"}
            </button>
            {!isViewMode && (
              <button type="button" className="submit-button" onClick={handleSubmit}>
                {mode === "create" ? "Crear" : "Guardar"}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoleFormModal;
