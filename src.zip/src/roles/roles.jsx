import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import RoleFormModal from "./RoleFormModal";
import DeleteConfirmationModal from "./DeleteModal.jsx";
import RoleTable from "./RoleTable.jsx";
import { menuSections } from "../sidebar/sidebar.jsx";
import "../app.css";
import "./roles.css";

const Roles = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [formMode, setFormMode] = useState("create");
  const [currentRoleId, setCurrentRoleId] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [activeTab, setActiveTab] = useState("activos");

  const itemsPerPage = 7;

  const [rolesData, setRolesData] = useState([
    { id: "R001", nombre: "Administrador", descripcion: "Acceso completo al sistema", permisos: 15, activo: true, modules: [] },
    { id: "R002", nombre: "Usuario", descripcion: "Acceso limitado a ciertas funcionalidades", permisos: 5, activo: true, modules: [] },
    { id: "R003", nombre: "Invitado", descripcion: "Acceso muy limitado, solo lectura", permisos: 1, activo: false, modules: [] },
    { id: "R004", nombre: "Editor", descripcion: "Puede editar contenidos", permisos: 6, activo: true, modules: [] },
    { id: "R005", nombre: "Supervisor", descripcion: "Monitorea sin editar", permisos: 4, activo: true, modules: [] },
    { id: "R006", nombre: "Analista", descripcion: "Revisa estadísticas", permisos: 3, activo: true, modules: [] },
    { id: "R007", nombre: "Soporte", descripcion: "Responde tickets", permisos: 2, activo: true, modules: [] },
    { id: "R008", nombre: "Soporte", descripcion: "Responde tickets", permisos: 2, activo: true, modules: [] },
    { id: "R009", nombre: "Auditor", descripcion: "Auditoría y control", permisos: 8, activo: true, modules: [] },
    { id: "R010", nombre: "Auditor", descripcion: "Auditoría y control", permisos: 8, activo: false, modules: [] },
  ]);

  const [formData, setFormData] = useState({
    id: "", nombre: "", descripcion: "", permisos: 0, activo: true, modules: [],
  });

  const filteredRoles = rolesData.filter(
    (rol) =>
      (rol.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rol.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rol.descripcion.toLowerCase().includes(searchTerm.toLowerCase())) &&
      rol.activo === (activeTab === "activos")
  );

  const totalPages = Math.ceil(filteredRoles.length / itemsPerPage);
  const paginatedRoles = filteredRoles.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const openCreateForm = () => {
    setFormMode("create");
    setIsFormOpen(true);
    setFormData({ id: "", nombre: "", descripcion: "", permisos: 0, activo: true, modules: [] });
  };

  const openEditForm = (roleId) => {
    const roleToEdit = rolesData.find((role) => role.id === roleId);
    if (!roleToEdit) return;

    setFormMode("edit");
    setCurrentRoleId(roleId);
    setIsFormOpen(true);
    setFormData({ ...roleToEdit });
  };

  const openViewForm = (roleId) => {
    const role = rolesData.find((r) => r.id === roleId);
    if (role) {
      setFormMode("view");
      setFormData({ ...role });
      setIsFormOpen(true);
    }
  };

  const openDeleteModal = (roleId) => {
    setCurrentRoleId(roleId);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    setRolesData(rolesData.filter((role) => role.id !== currentRoleId));
    setIsDeleteModalOpen(false);
    setIsFormOpen(false);
    setCurrentRoleId(null);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setCurrentRoleId(null);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = () => {
    if (formMode === "create") {
      const newId = "R" + (rolesData.length + 1).toString().padStart(3, "0");
      const newRole = { ...formData, id: newId, permisos: formData.modules.length };
      setRolesData([...rolesData, newRole]);
    } else {
      setRolesData(
        rolesData.map((role) =>
          role.id === currentRoleId
            ? { ...formData, id: currentRoleId, permisos: formData.modules.length }
            : role
        )
      );
    }
    closeForm();
  };

  const toggleRolEstado = (id) => {
    setRolesData(
      rolesData.map((rol) => (rol.id === id ? { ...rol, activo: !rol.activo } : rol))
    );
  };

  const handlePageChange = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  return (
    <div className="container">
      <h1>Cyber360 - Roles</h1>
      <div className="section-divider"></div>

      <div className="search-container">
        <input
          type="text"
          placeholder="Buscar rol"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
          className="search-input"
        />
        <button className="create-button" onClick={openCreateForm}>
          <FontAwesomeIcon icon={faPlus} /> Crear
        </button>
      </div>

      <div className="tabs">
        <button
          className={`tab-button ${activeTab === "activos" ? "active-tab" : ""}`}
          onClick={() => {
            setActiveTab("activos");
            setCurrentPage(1);
          }}
        >
          Roles Activos
        </button>
        <button
          className={`tab-button ${activeTab === "inactivos" ? "active-tab" : ""}`}
          onClick={() => {
            setActiveTab("inactivos");
            setCurrentPage(1);
          }}
        >
          Roles Inactivos
        </button>
      </div>

      <RoleTable
        roles={paginatedRoles}
        onView={openViewForm}
        onEdit={openEditForm}
        onDelete={openDeleteModal}
        onToggleEstado={toggleRolEstado}
      />

      {totalPages > 1 && (
        <div className="pagination-controls">
          <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
            &lt;
          </button>
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i + 1}
              className={currentPage === i + 1 ? "active-page" : ""}
              onClick={() => handlePageChange(i + 1)}
            >
              {i + 1}
            </button>
          ))}
          <button
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            &gt;
          </button>
        </div>
      )}

      <RoleFormModal
        isOpen={isFormOpen}
        onClose={closeForm}
        formData={formData}
        onChange={handleChange}
        onSubmit={handleSubmit}
        onDelete={() => openDeleteModal(currentRoleId)}
        menuSections={menuSections}
        mode={formMode}
      />

      <DeleteConfirmationModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDelete}
        itemName={rolesData.find((r) => r.id === currentRoleId)?.nombre || "este rol"}
      />
    </div>
  );
};

export default Roles;
